# 1_6-stack_dups
